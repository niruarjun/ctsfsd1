package com.jpassion.di.services;

public interface CustomerService {
	public String getCustomerGreeting();
}
